from Pessoa import Pessoa

class Fisica(Pessoa):
    def __init__(self, CPF, idade, peso, altura):
        super().__init__(codigo, nome, endereco, telefone)
        self.__CPF = __CPF
        self.idade = idade
        self.peso = peso
        self.altura = altura

        def getCPF(self):
            return self.__CPF

        def setCPF(self, CPF):
            self __CPF = __CPF

        def getIdade(self):
            return self.idade

        def setIdade(self, idade):
            self idade = idade

        def getPeso(self):
            return self.peso

        def setPeso(self, peso):
            self peso = peso

        def getAltura(self):
            return self.altura

        def setAltura(self, altura):
            self altura = altura
        
        def _imprimeCPF(self):
            print("CPF: " + self.__CPF)