class Pessoa:
    def __init__(self, codigo, nome, endereco, telefone):
        self.codigo = codigo
        self.nome = nome
        self.endereco = endereco

    def setCodigo(self, codigo):
        self.codigo = codigo

    def setNome(self, nome):
        self.nome = nome

    def setEndereco(self, endereco):
        self.endreco = endereco

    def setTelefone(self, telefone):
        self.telefone = telefone
    
    def getCodigo(self):
        return self.codigo
    
    def getNome(self):
        return self.Nome

    def getEndereco(self):
        return self.endereco

    def getTelefone(self):
        return self.Telefone

    def imprimeNome(self):
        print("Nome: " + self.nome)

    def imprimeTelefone(self):
        print("Telefone: " + self.nome)
