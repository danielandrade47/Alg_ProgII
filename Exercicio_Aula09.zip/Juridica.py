from Pessoa import Pessoa

class Juridica(Pessoa):
    def __init__(self, CNPJ, inscricaoEstadual, quantidadeFuncionarios):
        super().__init__(codigo, nome, endereco, telefone)
        self.CNPJ = CNPJ
        self.inscricaoEstadual = inscricaoEstadual
        self.quantidadeFuncionarios = quantidadeFuncionarios

        def getCNPJ(self):
            return self.CNPJ

        def getCNPJ(self, CNPJ):
            self CNPJ = CNPJ

        def getInscricaoEstadual(self):
            return self.inscricaoEstadual

        def setInscricaoEstadual(self, inscricaoEstadual):
            self inscricaoEstadual = inscricaoEstadual

        def getQuantidadeFuncionarios(self):
            return self.quantidadeFuncionarios

        def setQuantidadeFuncionarios(self, quantidadeFuncionarios):
            self quantidadeFuncionarios = quantidadeFuncionarios

        def _imprimeCNPJ(self):
            print("CNPJ: " + self.CNPJ)